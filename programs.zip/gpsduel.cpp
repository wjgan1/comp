//foreverbronze

#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <queue>
using namespace std;

#define in1 "data.in"
#define in2 "gpsduel.in"
#define out1 "data.out"
#define out2 "gpsduel.out"

int min_a[10000], loc_a[10000], heap_a[10000];
bool vis_a[10000];


bool vis_a[10000];

shortest_path(int src, int dest, vector<vector<int>> adj)
{

}

int main()
{
	ifstream fin(in1);
	ofstream fout(out1);

	fin.close();
	fout.close();

	return 0;
}