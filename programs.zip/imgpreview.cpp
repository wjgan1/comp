#include <iostream>
#include <cstdio>
#include <string>
using namespace std;

int N, A, B, T;
string img;
vector<pair<int, int> >

int main() {
	
}