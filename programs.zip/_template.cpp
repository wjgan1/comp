/*
ID: wgan8561
PROG: 
LANG: C++
*/

#include <iostream>
#include <cstdio>
using namespace std;
 
int main()
{
  	ios_base::sync_with_stdio(0);
    freopen(".in", "r", stdin);
    freopen(".out", "w", stdout);
}