//foreverbronze
//http://usaco.org/index.php?page=viewproblem2&cpid=341
//2/12/2015

#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>

using namespace std;

#define in1 "data.in"
#define in2 "nocow.in"
#define out1 "data.out"
#define out2 "nocow.out"

int N, K;
vector<vector<string>> v;

int main()
{
	ifstream fin(in1);
	ofstream fout(out1);

	fin >> N >> K;


	fin.close();
	fout.close();

	return 0;
}