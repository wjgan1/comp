/*
ID: wgan8561
PROG:
LANG: C++
*/

//foreverbronze
//problem link
//date

#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>

using namespace std;

#define in1 "data.in"
#define in2 ""
#define out1 "data.out"
#define out2 ""

int main()
{
	ifstream fin(in1);
	ofstream fout(out1);

	fin.close();
	fout.close();

	return 0;
}