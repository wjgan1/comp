#include <fstream>
#include <iostream>

int main()
{
	ifstream in("data.in");
	ofstream out("data.out");

	int N;
	in >> N;

	for (int i = 0; i < N; ++i)
	{
		
	}
}